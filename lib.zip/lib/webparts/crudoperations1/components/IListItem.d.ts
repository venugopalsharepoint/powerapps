export interface IListItem {
    Title?: string;
    Id: number;
}
//# sourceMappingURL=IListItem.d.ts.map