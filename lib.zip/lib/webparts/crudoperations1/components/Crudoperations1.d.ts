import * as React from 'react';
import { ICrudoperations1Props } from './ICrudoperations1Props';
import { ICrudoperations1state } from './ICrudoperations1state';
export default class Crudoperations1 extends React.Component<ICrudoperations1Props, ICrudoperations1state> {
    constructor(props: ICrudoperations1Props, state: ICrudoperations1state);
    render(): React.ReactElement<ICrudoperations1Props>;
    private createItem;
    private readItem;
    private updateItem;
    private getLatestItemId;
    private deleteItem;
}
//# sourceMappingURL=Crudoperations1.d.ts.map