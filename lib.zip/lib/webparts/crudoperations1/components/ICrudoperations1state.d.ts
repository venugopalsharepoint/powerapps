import { IListItem } from './IListItem';
export interface ICrudoperations1state {
    status: string;
    items: IListItem[];
}
//# sourceMappingURL=ICrudoperations1state.d.ts.map