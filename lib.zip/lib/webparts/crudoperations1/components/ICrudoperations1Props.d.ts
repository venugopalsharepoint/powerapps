import { SPHttpClient } from '@microsoft/sp-http';
export interface ICrudoperations1Props {
    listName: string;
    spHttpClient: SPHttpClient;
    siteUrl: string;
}
//# sourceMappingURL=ICrudoperations1Props.d.ts.map