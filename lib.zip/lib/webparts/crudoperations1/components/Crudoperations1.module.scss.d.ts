declare const styles: {
    crudoperations1: string;
    container: string;
    row: string;
    column: string;
    'ms-Grid': string;
    title: string;
    subTitle: string;
    description: string;
    button: string;
    label: string;
};
export default styles;
//# sourceMappingURL=Crudoperations1.module.scss.d.ts.map