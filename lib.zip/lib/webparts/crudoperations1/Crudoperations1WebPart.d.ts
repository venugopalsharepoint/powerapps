import { IPropertyPaneConfiguration } from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
export interface ICrudoperations1WebPartProps {
    listName: string;
}
export default class Crudoperations1WebPart extends BaseClientSideWebPart<ICrudoperations1WebPartProps> {
    render(): void;
    protected onDispose(): void;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
//# sourceMappingURL=Crudoperations1WebPart.d.ts.map