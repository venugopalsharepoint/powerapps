import * as React from 'react';
import * as ReactDom from 'react-dom';
import { Version } from '@microsoft/sp-core-library';
import {
  IPropertyPaneConfiguration,
  PropertyPaneTextField
} from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';

import * as strings from 'Crudoperations1WebPartStrings';
import Crudoperations1 from './components/Crudoperations1';
import { ICrudoperations1state } from './components/ICrudoperations1state';


import { SPHttpClient, SPHttpClientResponse } from '@microsoft/sp-http';
import { ICrudoperations1Props } from './components/ICrudoperations1Props';

export interface ICrudoperations1WebPartProps {
  listName: string;
}

export default class Crudoperations1WebPart extends BaseClientSideWebPart <ICrudoperations1WebPartProps> {

  public render(): void {
    const element: React.ReactElement<ICrudoperations1Props> = React.createElement(
      Crudoperations1,
      {
        listName: this.properties.listName,
          
        spHttpClient: this.context.spHttpClient,  
        siteUrl: this.context.pageContext.web.absoluteUrl  
      }
    );

    ReactDom.render(element, this.domElement);
  }

  protected onDispose(): void {
    ReactDom.unmountComponentAtNode(this.domElement);
  }

  

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: {
            description: strings.PropertyPaneDescription
          },
          groups: [
            {
              groupName: strings.BasicGroupName,
              groupFields: [  
                  PropertyPaneTextField('listName', {  
                    label: strings.ListNameFieldLabel 
                })
              ]
            }
          ]
        }
      ]
    };
  }
}
