declare interface ICrudoperations1WebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  ListNameFieldLabel: string;
}

declare module 'Crudoperations1WebPartStrings' {
  const strings: ICrudoperations1WebPartStrings;
  export = strings;
}
