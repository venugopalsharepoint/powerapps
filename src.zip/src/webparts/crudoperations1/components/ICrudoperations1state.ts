import { IListItem } from './IListItem';  
  
export interface ICrudoperations1state {  
  status: string;  
  items: IListItem[];  
}