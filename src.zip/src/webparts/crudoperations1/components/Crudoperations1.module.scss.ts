/* tslint:disable */
require("./Crudoperations1.module.css");
const styles = {
  crudoperations1: 'crudoperations1_c3d5a5e9',
  container: 'container_c3d5a5e9',
  row: 'row_c3d5a5e9',
  column: 'column_c3d5a5e9',
  'ms-Grid': 'ms-Grid_c3d5a5e9',
  title: 'title_c3d5a5e9',
  subTitle: 'subTitle_c3d5a5e9',
  description: 'description_c3d5a5e9',
  button: 'button_c3d5a5e9',
  label: 'label_c3d5a5e9'
};

export default styles;
/* tslint:enable */